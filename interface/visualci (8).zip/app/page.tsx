"use client"

import VisualCICDEnvironment from "../visual-cicd-interface"

export default function SyntheticV0PageForDeployment() {
  return (
    <div className="h-full w-full m-0 p-0">
      <VisualCICDEnvironment />
    </div>
  )
}
